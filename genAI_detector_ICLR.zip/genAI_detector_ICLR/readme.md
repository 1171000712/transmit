# Manifold Induced Biases for Zero-shot and Few-shot Detection of Generated Images

Distinguishing between real and AI-generated images presents a timely and significant challenge. Despite extensive research in the (semi-)supervised regime, only recently, zero-shot and few-shot solutions have emerged as promising approaches to this task: They alleviate the ongoing data maintenance, which quickly becomes
outdated due to advances in generative technologies. We identify two main gaps: (1) a lack of theoretical grounding for the methods, and (2) significant room for performance improvements in zero-shot and few-shot regimes. Our approach is founded on understanding and quantifying the biases inherent in generated content, where we use these quantities as criteria for characterizing generated images.
Specifically, we explore the biases induced by the implicitly learned manifold of a pre-trained diffusion model: Through score-function analysis, curvature and gradient of the probability manifold are approximated in the zero-shot setting - yielding a scalar criterion for classification. We further extend our contribution to the few-shot setting by employing a mixture-of-experts methodology. Empirical results across 20 generative models demonstrate that our method outperforms
current approaches in both zero-shot and few-shot settings. This work advances the theoretical understanding and practical usage of generated content biases through the lens of manifold analysis

![Alt text](images/method_pipeline_1.png)

## Table of Contents

- [Installation](#installation)
- [Usage](#usage)

## Installation

Follow these instructions to install and set up the project. Make sure to meet all prerequisites and dependencies.

1. **Place the Repository in you VM**:

    Copy the whole code folder to your virtual machine

2. **Create a New Conda Environment**:

    Create a new conda environment using the `environment.yml` file provided in the repository:

    ```bash
    conda env create -f environment.yml -n my_new_env
    ```

3. **Activate the Environment**:

    Activate the newly created environment:

    ```bash
    conda activate your-env-name
    ```


4. **Execution to obtain our criterion**:

    Run

    ```bash
    python zero_shot_bias_driven_criterion.py
    ```
    Our criterion to distingish real from generated images will be calculated and printed on 2 sanity-check images as:
    
    ```bash
    Image:
    ./example_images/generated_robot_detective.png
    Criterion:
    0.5263287425041199
    Image:
    ./example_images/real_dog.png
    Criterion:
    0.32599151134490967
    ```

5. **Dataset Instructions**:
    
    You can reproduce our results, by obtaining the criterion on the ~200,000 images datasets. Our calibration and test sets are compiled from three benchmark datasets: [CNNSpot](https://github.com/PeterWang512/CNNDetection), [Universal Fake Detect](https://github.com/WisconsinAIVision/UniversalFakeDetect), and [GenImage](https://github.com/GenImage-Dataset/GenImage). For replicability purposes we provide the detalied images used and their train-test (real-generated) split in the following excel file [Dataset Download Link](https://tinyurl.com/zeroshotimplementation).
    
<!-- 
## Usage

### Run Our Detection Method

To check the reported results of our zero-shot detection method, please run the following command:
python run_detection.py

Detection results will be placed inside:
"temp_outputs/design_5_orig/NIPSREADY_skip_num_images_None_num_noise_4_shuffle_images_True_im2latents_True_dynamic11_True_scalefact_True/res"


Training our detector is possible but requires a GPU. 
We will provide detailed instructions for this functionality in the future. -->

Thank you for using our project! 